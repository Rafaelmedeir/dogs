# hike-project-1
Projeto de criação de uma landing page sobre adoção de cães.
